const CACHE = 'assakinah-v3';
const ASSETS = [
  './', './index.html', './manifest.webmanifest',
  './vendor/app.css', './vendor/lucide.min.js', './vendor/fonts/inter.css',
  './vendor/fonts/inter-latin-300-normal.woff2', './vendor/fonts/inter-latin-400-normal.woff2',
  './vendor/fonts/inter-latin-500-normal.woff2', './vendor/fonts/inter-latin-600-normal.woff2',
  './vendor/fonts/inter-latin-700-normal.woff2',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== 'assakinah-meta').map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Halaman: jaringan dulu (selalu versi terbaru), cadangan cache saat offline. Aset: cache dulu.
// Permintaan /api/ tidak pernah di-cache.
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  if (req.mode === 'navigate' || url.pathname.endsWith('.html') || url.pathname.endsWith('/sw.js')) {
    e.respondWith(
      fetch(req).then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); return res; })
        .catch(() => caches.match(req, { ignoreSearch: true }).then(h => h || caches.match('./index.html')))
    );
    return;
  }
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(hit => hit || fetch(req).then(res => {
      const copy = res.clone();
      caches.open(CACHE).then(c => c.put(req, copy));
      return res;
    }))
  );
});

// Notifikasi push: server mengirim sinyal kosong, lalu kita ambil isi notifikasi terbaru.
self.addEventListener('push', e => {
  e.waitUntil((async () => {
    let title = 'Keuangan Dusun Assakinah', body = 'Ada pembaruan data dusun.';
    try {
      const meta = await caches.open('assakinah-meta');
      const kr = await meta.match('/__devicekey');
      if (kr) {
        const key = await kr.text();
        const r = await fetch('/api/push/latest?key=' + encodeURIComponent(key), { cache: 'no-store' });
        if (r.ok) { const n = await r.json(); if (n.title) { title = n.title; body = n.body; } }
      }
    } catch (err) {}
    // Jika aplikasi sedang terbuka dan terlihat, cukup toast di dalam aplikasi.
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    if (wins.some(w => w.visibilityState === 'visible')) return;
    await self.registration.showNotification(title, {
      body, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: 'assakinah-update', renotify: true
    });
  })());
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const c of list) if ('focus' in c) return c.focus();
    return self.clients.openWindow('./index.html');
  }));
});
