// Server Keuangan Dusun Assakinah
// Tanpa dependensi npm: hanya Node.js >= 22.5 (http, crypto, node:sqlite).
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:admin@assakinah.local';
fs.mkdirSync(DATA_DIR, { recursive: true });

// ───────────────────────── Database ─────────────────────────
const db = new DatabaseSync(path.join(DATA_DIR, 'assakinah.db'));
db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (
  username TEXT PRIMARY KEY COLLATE NOCASE,
  salt TEXT NOT NULL, hash TEXT NOT NULL,
  name TEXT NOT NULL, jabatan TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL CHECK (role IN ('admin','pemuda')),
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL CHECK (type IN ('in','out')),
  date TEXT NOT NULL, title TEXT NOT NULL, desc TEXT NOT NULL DEFAULT '', amount INTEGER NOT NULL,
  by_user TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS warga (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, jabatan TEXT NOT NULL,
  role TEXT NOT NULL, username TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tagihan (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due TEXT NOT NULL,
  amount INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS agenda (
  id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, status TEXT NOT NULL,
  title TEXT NOT NULL, desc TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
  actor TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS push_subs (
  endpoint TEXT PRIMARY KEY, p256dh TEXT, auth TEXT, username TEXT,
  device_key TEXT NOT NULL, created_at INTEGER NOT NULL
);
`);

const now = () => Date.now();
const getMeta = (k) => db.prepare('SELECT v FROM meta WHERE k=?').get(k)?.v;
const setMeta = (k, v) => db.prepare('INSERT INTO meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, v);

// Rahasia token & kunci VAPID dibuat sekali, disimpan di database.
if (!getMeta('token_secret')) setMeta('token_secret', crypto.randomBytes(32).toString('hex'));
if (!getMeta('vapid_private')) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  setMeta('vapid_private', JSON.stringify(privateKey.export({ format: 'jwk' })));
  const pj = publicKey.export({ format: 'jwk' });
  setMeta('vapid_public', Buffer.concat([Buffer.from([4]), Buffer.from(pj.x, 'base64url'), Buffer.from(pj.y, 'base64url')]).toString('base64url'));
}
const TOKEN_SECRET = getMeta('token_secret');
const VAPID_PUBLIC = getMeta('vapid_public');
const VAPID_KEY = crypto.createPrivateKey({ key: JSON.parse(getMeta('vapid_private')), format: 'jwk' });

// ───────────────────────── Password & token ─────────────────────────
function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 32).toString('hex'); }
function createUser({ username, password, name, jabatan, phone = '', role }) {
  const salt = crypto.randomBytes(16).toString('hex');
  db.prepare('INSERT INTO users(username,salt,hash,name,jabatan,phone,role,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(username, salt, hashPw(password, salt), name, jabatan, phone, role, now());
}
function publicUser(u) {
  return { username: u.username, name: u.name, jabatan: u.jabatan, phone: u.phone, role: u.role, isAdmin: u.role === 'admin' };
}
function signToken(username) {
  const body = Buffer.from(JSON.stringify({ u: username, e: now() + 90 * 864e5 })).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function verifyToken(tok) {
  if (!tok || typeof tok !== 'string' || !tok.includes('.')) return null;
  const [body, sig] = tok.split('.');
  const good = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (p.e < now()) return null;
    const u = db.prepare('SELECT * FROM users WHERE username=?').get(p.u);
    return u || null;
  } catch { return null; }
}

// Data awal: SATU akun admin. (Hanya dibuat jika belum ada admin sama sekali.)
if (!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()) {
  createUser({ username: 'Admin', password: 'Admin123123', name: 'Admin', jabatan: 'Admin', phone: '', role: 'admin' });
  db.prepare('INSERT INTO warga(name,jabatan,role,username,created_at) VALUES(?,?,?,?,?)').run('Admin', 'Admin', 'Admin', 'Admin', now());
  console.log('Akun admin awal dibuat: Admin / Admin123123 (segera ganti kata sandi)');
}

// ───────────────────────── Realtime (SSE) ─────────────────────────
const clients = new Set();
function broadcast(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of clients) { try { c.write(msg); } catch { clients.delete(c); } }
}
setInterval(() => { for (const c of clients) { try { c.write(': ping\n\n'); } catch { clients.delete(c); } } }, 25000);

// ───────────────────────── Web Push (VAPID, tanpa payload) ─────────────────────────
function vapidHeader(endpoint) {
  const aud = new URL(endpoint).origin;
  const head = Buffer.from(JSON.stringify({ typ: 'JWT', alg: 'ES256' })).toString('base64url');
  const claims = Buffer.from(JSON.stringify({ aud, exp: Math.floor(now() / 1000) + 12 * 3600, sub: VAPID_SUBJECT })).toString('base64url');
  const sig = crypto.sign('sha256', Buffer.from(head + '.' + claims), { key: VAPID_KEY, dsaEncoding: 'ieee-p1363' }).toString('base64url');
  return `vapid t=${head}.${claims}.${sig}, k=${VAPID_PUBLIC}`;
}
async function sendPushAll(exceptUser) {
  const subs = db.prepare('SELECT endpoint, username FROM push_subs').all();
  await Promise.all(subs.map(async (s) => {
    try {
      const r = await fetch(s.endpoint, {
        method: 'POST',
        headers: { Authorization: vapidHeader(s.endpoint), TTL: '86400', Urgency: 'high', 'Content-Length': '0' },
      });
      if (r.status === 404 || r.status === 410) db.prepare('DELETE FROM push_subs WHERE endpoint=?').run(s.endpoint);
    } catch (e) { /* perangkat offline: dicoba lagi pada notifikasi berikutnya */ }
  }));
}
function notify(title, body, actor) {
  const info = db.prepare('INSERT INTO notifications(title,body,actor,created_at) VALUES(?,?,?,?)').run(title, body, actor || null, now());
  const n = { id: Number(info.lastInsertRowid), title, body, actor: actor || null, created_at: now() };
  broadcast('notif', n);
  sendPushAll(actor).catch(() => {});
  return n;
}
const rp = (n) => 'Rp ' + Number(n).toLocaleString('id-ID');

// ───────────────────────── HTTP helpers ─────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8',
};
function send(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(b);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', (c) => { s += c; if (s.length > 1e6) { reject(new Error('too big')); req.destroy(); } });
    req.on('end', () => { try { resolve(s ? JSON.parse(s) : {}); } catch { reject(new Error('bad json')); } });
  });
}
const str = (v, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const num = (v) => { const n = Math.round(Number(v)); return Number.isFinite(n) && n > 0 && n < 1e13 ? n : null; };

function snapshot() {
  return {
    transactions: db.prepare('SELECT id,type,date,title,desc,amount,by_user FROM transactions ORDER BY id DESC').all(),
    warga: db.prepare('SELECT id,name,jabatan,role,username FROM warga ORDER BY id DESC').all(),
    tagihan: db.prepare('SELECT id,title,due,amount FROM tagihan ORDER BY id DESC').all(),
    agenda: db.prepare('SELECT id,date,status,title,desc FROM agenda ORDER BY id DESC').all(),
    notifications: db.prepare('SELECT id,title,body,actor,created_at FROM notifications ORDER BY id DESC LIMIT 50').all(),
  };
}

// ───────────────────────── API ─────────────────────────
const loginAttempts = new Map(); // pembatas sederhana anti tebak sandi
function tooMany(ip) {
  const a = (loginAttempts.get(ip) || []).filter((t) => t > now() - 10 * 60e3);
  loginAttempts.set(ip, a);
  return a.length >= 20;
}

async function api(req, res, url) {
  const route = req.method + ' ' + url.pathname;
  const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress;

  if (route === 'GET /api/health') return send(res, 200, { ok: true });
  if (route === 'GET /api/vapid') return send(res, 200, { key: VAPID_PUBLIC });

  if (route === 'POST /api/login') {
    if (tooMany(ip)) return send(res, 429, { error: 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.' });
    const b = await readBody(req);
    const u = db.prepare('SELECT * FROM users WHERE username=?').get(str(b.username, 60));
    const ok = u && crypto.timingSafeEqual(Buffer.from(hashPw(String(b.password || ''), u.salt)), Buffer.from(u.hash));
    if (!ok) { loginAttempts.get(ip).push(now()); return send(res, 401, { error: 'Username atau kata sandi salah.' }); }
    return send(res, 200, { token: signToken(u.username), user: publicUser(u) });
  }

  if (route === 'POST /api/register') {
    if (tooMany(ip)) return send(res, 429, { error: 'Terlalu banyak percobaan.' });
    loginAttempts.get(ip)?.push(now());
    const b = await readBody(req);
    const username = str(b.username, 40), name = str(b.name, 80), jabatan = str(b.jabatan, 80), phone = str(b.phone, 30);
    const password = String(b.password || '');
    if (!username || !name || !jabatan || password.length < 6) return send(res, 400, { error: 'Lengkapi data. Kata sandi minimal 6 karakter.' });
    if (!/^[A-Za-z0-9_.-]+$/.test(username)) return send(res, 400, { error: 'Username hanya huruf, angka, titik, strip, garis bawah.' });
    if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) return send(res, 409, { error: 'Username sudah terdaftar. Gunakan yang lain.' });
    // Pendaftaran mandiri selalu berperan Pemuda; admin yang bisa menaikkan peran.
    createUser({ username, password, name, jabatan, phone, role: 'pemuda' });
    db.prepare('INSERT INTO warga(name,jabatan,role,username,created_at) VALUES(?,?,?,?,?)').run(name, jabatan, 'Pemuda', username, now());
    const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
    notify('Warga Baru Terdaftar', `${name} (${jabatan}) bergabung.`, username);
    broadcast('changed', { entity: 'warga' });
    return send(res, 200, { token: signToken(u.username), user: publicUser(u) });
  }

  // ── Selain endpoint di atas, wajib login ──
  const tok = (req.headers.authorization || '').replace(/^Bearer /, '') || url.searchParams.get('token');
  const me = verifyToken(tok);
  if (!me) return send(res, 401, { error: 'Sesi berakhir. Silakan masuk lagi.' });
  const isAdmin = me.role === 'admin';
  const needAdmin = () => { send(res, 403, { error: 'Akses ditolak: hanya admin.' }); return false; };

  if (route === 'GET /api/me') return send(res, 200, { user: publicUser(me) });
  if (route === 'GET /api/data') return send(res, 200, snapshot());

  if (route === 'GET /api/stream') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write('retry: 3000\n\n');
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }

  // Notifikasi terbaru untuk service worker (autentikasi pakai kunci perangkat)
  if (route === 'GET /api/push/latest') {
    const key = url.searchParams.get('key');
    const sub = key && db.prepare('SELECT 1 FROM push_subs WHERE device_key=?').get(key);
    if (!sub) return send(res, 404, {});
    return send(res, 200, db.prepare('SELECT id,title,body,created_at FROM notifications ORDER BY id DESC LIMIT 1').get() || {});
  }

  if (route === 'POST /api/push/subscribe') {
    const b = await readBody(req);
    const s = b.subscription;
    if (!s?.endpoint || !/^https:\/\//.test(s.endpoint)) return send(res, 400, { error: 'Langganan tidak valid.' });
    const deviceKey = crypto.randomBytes(24).toString('hex');
    db.prepare(`INSERT INTO push_subs(endpoint,p256dh,auth,username,device_key,created_at) VALUES(?,?,?,?,?,?)
      ON CONFLICT(endpoint) DO UPDATE SET username=excluded.username, device_key=excluded.device_key`)
      .run(s.endpoint, s.keys?.p256dh || '', s.keys?.auth || '', me.username, deviceKey, now());
    return send(res, 200, { deviceKey });
  }
  if (route === 'POST /api/push/unsubscribe') {
    const b = await readBody(req);
    db.prepare('DELETE FROM push_subs WHERE endpoint=?').run(str(b.endpoint, 2000));
    return send(res, 200, { ok: true });
  }

  // Transaksi
  if (route === 'POST /api/transactions') {
    const b = await readBody(req);
    const amount = num(b.amount), title = str(b.title, 120);
    let type = b.type === 'out' ? 'out' : 'in';
    let date = str(b.date, 40) || 'Hari Ini', desc = str(b.desc, 200);
    if (!amount || !title) return send(res, 400, { error: 'Judul dan nominal wajib diisi.' });
    if (!isAdmin) { type = 'in'; if (b.donation !== true) return needAdmin(); } // pemuda hanya boleh donasi
    db.prepare('INSERT INTO transactions(type,date,title,desc,amount,by_user,created_at) VALUES(?,?,?,?,?,?,?)').run(type, date, title, desc, amount, me.username, now());
    notify(b.donation ? 'Donasi Masuk! 💖' : 'Transaksi Baru Dicatat', `${title} (${type === 'in' ? '+' : '-'}${rp(amount)}) oleh ${me.name}`, me.username);
    broadcast('changed', { entity: 'transactions' });
    return send(res, 200, { ok: true });
  }
  let m;
  if ((m = url.pathname.match(/^\/api\/(transactions|warga|tagihan|agenda)\/(\d+)$/)) && req.method === 'DELETE') {
    if (!isAdmin) return needAdmin();
    const [, table, id] = m;
    if (table === 'warga') {
      const w = db.prepare('SELECT * FROM warga WHERE id=?').get(id);
      if (w?.username) {
        if (w.username.toLowerCase() === me.username.toLowerCase()) return send(res, 400, { error: 'Tidak bisa menghapus akun Anda sendiri.' });
        db.prepare('DELETE FROM users WHERE username=?').run(w.username);
      }
    }
    db.prepare(`DELETE FROM ${table} WHERE id=?`).run(id);
    const label = { transactions: ['Data Kas Diperbarui', 'Sebuah transaksi telah dihapus oleh Admin.'], warga: ['Data Warga Diperbarui', 'Data warga telah diperbarui oleh Admin.'], tagihan: ['Tagihan Diperbarui', 'Sebuah tagihan telah dihapus oleh Admin.'], agenda: ['Agenda Diperbarui', 'Agenda kegiatan dusun telah dihapus.'] }[table];
    notify(label[0], label[1], me.username);
    broadcast('changed', { entity: table });
    return send(res, 200, { ok: true });
  }

  if (route === 'POST /api/warga') {
    if (!isAdmin) return needAdmin();
    const b = await readBody(req);
    const name = str(b.name, 80), jabatan = str(b.jabatan, 80), role = b.role === 'Admin' ? 'Admin' : 'Pemuda';
    if (!name || !jabatan) return send(res, 400, { error: 'Nama dan jabatan wajib diisi.' });
    db.prepare('INSERT INTO warga(name,jabatan,role,username,created_at) VALUES(?,?,?,?,?)').run(name, jabatan, role, null, now());
    notify('Info Warga Ditambahkan', `${name} (${jabatan}) terdaftar.`, me.username);
    broadcast('changed', { entity: 'warga' });
    return send(res, 200, { ok: true });
  }
  if ((m = url.pathname.match(/^\/api\/warga\/(\d+)\/role$/)) && req.method === 'PUT') {
    if (!isAdmin) return needAdmin();
    const w = db.prepare('SELECT * FROM warga WHERE id=?').get(m[1]);
    if (!w?.username) return send(res, 400, { error: 'Hanya warga yang punya akun yang bisa diubah perannya.' });
    const b = await readBody(req);
    const role = b.role === 'admin' ? 'admin' : 'pemuda';
    if (role === 'pemuda' && w.username.toLowerCase() === me.username.toLowerCase()) return send(res, 400, { error: 'Tidak bisa menurunkan peran Anda sendiri.' });
    db.prepare('UPDATE users SET role=? WHERE username=?').run(role, w.username);
    db.prepare('UPDATE warga SET role=? WHERE id=?').run(role === 'admin' ? 'Admin' : 'Pemuda', w.id);
    notify('Peran Diubah', `${w.name} kini berperan ${role === 'admin' ? 'Admin' : 'Pemuda'}.`, me.username);
    broadcast('changed', { entity: 'warga' });
    return send(res, 200, { ok: true });
  }
  if (route === 'POST /api/tagihan') {
    if (!isAdmin) return needAdmin();
    const b = await readBody(req);
    const title = str(b.title, 120), due = str(b.due, 60), amount = num(b.amount);
    if (!title || !due || !amount) return send(res, 400, { error: 'Lengkapi data tagihan.' });
    db.prepare('INSERT INTO tagihan(title,due,amount,created_at) VALUES(?,?,?,?)').run(title, due, amount, now());
    notify('Tagihan Baru', `Tagihan "${title}" (${rp(amount)}) telah diterbitkan.`, me.username);
    broadcast('changed', { entity: 'tagihan' });
    return send(res, 200, { ok: true });
  }
  if (route === 'POST /api/agenda') {
    if (!isAdmin) return needAdmin();
    const b = await readBody(req);
    const date = str(b.date, 60), title = str(b.title, 120), desc = str(b.desc, 400);
    if (!date || !title) return send(res, 400, { error: 'Tanggal dan judul wajib diisi.' });
    db.prepare('INSERT INTO agenda(date,status,title,desc,created_at) VALUES(?,?,?,?,?)').run(date, 'Mendatang', title, desc, now());
    notify('Agenda Kegiatan Baru', `Agenda "${title}" telah ditambahkan.`, me.username);
    broadcast('changed', { entity: 'agenda' });
    return send(res, 200, { ok: true });
  }
  if ((m = url.pathname.match(/^\/api\/agenda\/(\d+)\/status$/)) && req.method === 'PUT') {
    if (!isAdmin) return needAdmin();
    const b = await readBody(req);
    db.prepare('UPDATE agenda SET status=? WHERE id=?').run(b.status === 'Selesai' ? 'Selesai' : 'Mendatang', m[1]);
    broadcast('changed', { entity: 'agenda' });
    return send(res, 200, { ok: true });
  }

  if (route === 'POST /api/password') {
    const b = await readBody(req);
    const np = String(b.newPassword || '');
    const ok = crypto.timingSafeEqual(Buffer.from(hashPw(String(b.oldPassword || ''), me.salt)), Buffer.from(me.hash));
    if (!ok) return send(res, 400, { error: 'Kata sandi lama salah.' });
    if (np.length < 6) return send(res, 400, { error: 'Kata sandi baru minimal 6 karakter.' });
    const salt = crypto.randomBytes(16).toString('hex');
    db.prepare('UPDATE users SET salt=?, hash=? WHERE username=?').run(salt, hashPw(np, salt), me.username);
    return send(res, 200, { ok: true });
  }

  return send(res, 404, { error: 'Tidak ditemukan.' });
}

// ───────────────────────── Server ─────────────────────────
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    let p = decodeURIComponent(url.pathname);
    if (p === '/') p = '/index.html';
    const file = path.normalize(path.join(PUBLIC_DIR, p));
    if (!file.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404); return res.end('Not found');
    }
    const ext = path.extname(file);
    const noCache = ext === '.html' || p === '/sw.js' || ext === '.webmanifest';
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': noCache ? 'no-cache' : 'public, max-age=86400' });
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    if (!res.headersSent) send(res, 400, { error: 'Permintaan tidak valid.' });
    else res.end();
  }
});
server.listen(PORT, () => console.log('Assakinah berjalan di port ' + PORT));
